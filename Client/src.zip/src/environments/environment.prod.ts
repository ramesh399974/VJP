export const environment = {
  production: true,
  API_URL : "https://localhost:3000",
  IMG_URL : "https://localhost:80",
};
