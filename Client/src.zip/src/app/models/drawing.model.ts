export interface Drawing {
    id: number;
    drgCode: number;
    partNum: number;
    revNo:string;
    revDate:string;
    customerName:string;
}