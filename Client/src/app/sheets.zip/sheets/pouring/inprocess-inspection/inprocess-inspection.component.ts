import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inprocess-inspection',
  templateUrl: './inprocess-inspection.component.html',
  styleUrls: ['./inprocess-inspection.component.css']
})
export class InprocessInspectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
